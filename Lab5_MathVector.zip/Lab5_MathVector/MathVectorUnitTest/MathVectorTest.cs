﻿using MathVectorNS;

namespace MathVectorUnitTest
{
    [TestClass]
    public sealed class MathVectorTest
    {
        [TestMethod]
        public void Constructors()
        {
            var vector1 = new MathVector(5);

            Assert.AreEqual(5, vector1.Dimensions);

            var vector2 = new MathVector(1, 2, 3);

            Assert.AreEqual(3, vector2.Dimensions);
            for (int i = 1; i < 4; ++i)
                Assert.AreEqual(i, vector2[i - 1]);
        }

        [TestMethod]
        public void Properties()
        {
            var vector1 = new MathVector(5);
            Assert.AreEqual(5, vector1.Dimensions);

            var vector2 = new MathVector(3, 4);
            Assert.AreEqual(5, vector2.Length, 1e-6);
        }

        [TestMethod]
        public void Methods()
        {

        }
    }
}
